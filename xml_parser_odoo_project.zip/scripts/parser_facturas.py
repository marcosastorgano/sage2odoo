
def parse(xml_file):
    print(f"Procesando facturas desde {xml_file}...")
    # Aquí va la lógica de parsing con lxml o ElementTree
